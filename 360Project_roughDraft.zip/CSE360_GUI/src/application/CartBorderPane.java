package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;

public class CartBorderPane extends BorderPane{
	private Button menu;
	private Button account;
	private Button checkout;
	FontWeight weight = FontWeight.BOLD;
	FontPosture posture = FontPosture.REGULAR;
	
	public CartBorderPane() {

		//cart for testing
		Cart currentCart = new Cart();
		MenuItem cheeseburgeritem = new MenuItem();
		cheeseburgeritem.createMenuItem("CheeseBurger", 5.0,"Ingredients: Beef Patty topped with cheddar cheese, lettuce, tomato, onion, mayonnaise on top of a sesame bun", "Food");
		
		//create all the panes for use
		VBox overAllCart = new VBox();
		Pane header = new Pane();
		VBox itemList = new VBox();
		Pane cheeseburger = new Pane();
		BorderPane info = new BorderPane();
		VBox infoOrder = new VBox();
		HBox infoO = new HBox();
		
		itemList.setPadding(new Insets(12, 12, 12, 12));
		info.setPadding(new Insets(12, 12, 12, 12));
		
		//create stuff to go into header pane
		Label title = new Label("Restaurant Name");
		title.setFont(Font.font("Hecvetica",weight, posture, 15));
		title.relocate(235, 10);
		account = new Button("Account");
		account.relocate(10, 10);
		menu = new Button("Back to Menu");
		menu.relocate(485, 10);
		
		
		checkout = new Button("Checkout");
		checkout.relocate(485,500);
		checkout.setPadding(new Insets(6, 6, 6, 6));

		
		Label viewMyOrder = new Label("View My Cart");
		viewMyOrder.relocate(220, 50);
		
		viewMyOrder.setFont(Font.font("Hecvetica",weight, posture, 24));
		Pane titleView = new Pane();
		titleView.getChildren().add(viewMyOrder);
		
		boolean added = currentCart.addItem(cheeseburgeritem);
		
		for(int itemsin = 0; itemsin < currentCart.numbercartItems(); itemsin++)
		{
			if(currentCart.findItem(cheeseburgeritem) != 0)
			{
				int numOfItem = currentCart.findItem(cheeseburgeritem);
				Label cb = new Label("\n\tCheese Burger\n\t\t$5");
				cb.resize(500, 75);
				
				VBox countbuttons = new VBox();
				Label count = new Label("Count: " + numOfItem);
				//Label num = new Label("1");
				Button remove = new Button("Remove");
				
				countbuttons.getChildren().addAll(count, remove);
				countbuttons.relocate(490,20);
				countbuttons.setPadding(new Insets(6, 6, 6, 6));
				
				//cb.setStyle("-fx-border-color: black");
				cheeseburger.setStyle("-fx-border-color: black");
				cheeseburger.relocate(20, 100);
				cheeseburger.getChildren().addAll(cb,countbuttons);
				cheeseburger.setMinHeight(75);
				cheeseburger.setMinWidth(540);
				
				itemList.getChildren().addAll(cheeseburger);
				
			}else if(currentCart.findItem(cheeseburgeritem) != 0)
			{
				
			}else if(currentCart.findItem(cheeseburgeritem) != 0)
			{
				
			}
		}
		
		//items in cart currently hard coded in
		
		
		/*Rectangle r1 = new Rectangle(50,100,500,100);
		r1.setStroke(Color.BLACK);
		r1.setFill(Color.WHITE);*/
		
		Label couponcode = new Label("EnterCoupon:");
		couponcode.relocate(320, 400);
		couponcode.setPadding(new Insets(6, 6, 6, 6));
		TextField enterCoupon = new TextField();
		enterCoupon.setPadding(new Insets(6, 6, 6, 6));
		enterCoupon.relocate(400, 400);
		
		Label itemsinorder = new Label("Items in order:");
		itemsinorder.relocate(320, 425);
		itemsinorder.setPadding(new Insets(6, 6, 6, 6));
		Label discount = new Label("Discount:");
		discount.relocate(320, 450);
		discount.setPadding(new Insets(6, 6, 6, 6));
		
		//create label for Total
		Label total = new Label("Total:");
		total.relocate(320, 475);
		total.setPadding(new Insets(6, 6, 6, 6));
		
		//Add everything to panes then add to overAllCart
		header.getChildren().addAll(account, title, menu);
		infoOrder.getChildren().addAll(couponcode,itemsinorder,discount,total,checkout);
		infoO.getChildren().addAll(infoOrder,enterCoupon);
		info.setRight(infoO);
		overAllCart.getChildren().addAll(header,titleView,itemList,info);
		
		this.setCenter(overAllCart);
		
		
	}
	
	public void buttonCheckout(Stage window, Scene test)
	{
		checkout.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonMenu(Stage window, Scene test)
	{
		menu.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonAccount(Stage window, Scene test)
	{
		account.setOnAction(e -> window.setScene(test));
	}
	
}
