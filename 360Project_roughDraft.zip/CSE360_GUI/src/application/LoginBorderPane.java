package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;

public class LoginBorderPane extends BorderPane{

	
	public LoginBorderPane() {
		
		VBox loginScreen = new VBox();
		BorderPane buttons = new BorderPane();
		loginScreen.setPadding(new Insets(12,12,12,12));
		
		Button crAcc = new Button("Create Account");

		//crAcc.relocate(50, 0);

		Button login = new Button("Login");

		TextField username = new TextField();

		//username.relocate(200, 0);

		TextField passwrd = new TextField();

		//passwrd.relocate(200, 50);

		Label usrnameL = new Label("Username");

		Label psswrd = new Label("Password");

		buttons.setLeft(crAcc);
		buttons.setRight(login);
		loginScreen.getChildren().addAll(username,psswrd,passwrd,usrnameL,buttons);
		
		this.setCenter(loginScreen);
	}
}
