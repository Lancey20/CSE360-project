package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.layout.StackPane;


public class Main extends Application {

	public Stage window;

	
	@Override
	public void start(Stage primaryStage) {
		try {
			window = primaryStage;
			
			//MenuBorderPane menu = new MenuBorderPane();
			LoginBorderPane login = new LoginBorderPane();
			CreateAccountBorderPane createAccount = new CreateAccountBorderPane();
			CartBorderPane cart = new CartBorderPane();
			OrderStatusBorderPane orderConf = new OrderStatusBorderPane();
			
			StackPane orderConfPane = new StackPane();
			orderConfPane.getChildren().add(orderConf);
			Scene orderConfScene = new Scene(orderConfPane, 500, 500);
			
			StackPane createAccountPane = new StackPane();
			createAccountPane.getChildren().add(createAccount);
			Scene createAccountScene = new Scene(createAccountPane, 800, 500);
			
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 500, 500);
			
			//calling all button handler type classes for cart
			cart.buttonCheckout(window, orderConfScene);
			cart.buttonMenu(window, orderConfScene); //orderConfScene will be changed to menu scene
			cart.buttonAccount(window, loginScene); //orderConfScene will be changed to account scene
			//when account button is pushed we will have to figure out how to check if user is already logged in and that
			//decides whether they go to login or account details
			
			
			//setting up overall window
			StackPane rootPane = new StackPane();
			rootPane.getChildren().add(cart); //will start with menu not cart but don't have menu yet
			Scene mainscene = new Scene(rootPane, 500, 500);
			window.setScene(mainscene);
			window.setHeight(600);
			window.setWidth(600);
			window.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
