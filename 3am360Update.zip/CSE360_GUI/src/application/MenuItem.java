package application;

public class MenuItem{
private String name;
private double price;
private String ingredients;
private String type;

	public void createMenuItem(String newName, double newPrice, String newIngredients, String newType){ 
		name = newName;
		price = newPrice;
		ingredients = newIngredients;
		type = newType;
	} 
	
	public void setName(String updateName){
	    name = updateName;
	}
	
	public void setPrice(double updatePrice)
	{
		price = updatePrice;
	}
	
	public void setIngredients(String updateIngredients)
	{
		ingredients = updateIngredients;
	}
	
	public void setType(String updateType)
	{
		type = updateType;
	}
	
	public String getName()
	{
		return name;
	}
	
	public double getPrice()
	{
		return price;
	}
	
	public String getIngredients()
	{
		return ingredients;
	}
	
	public String getType()
	{
		return type;
	}
}