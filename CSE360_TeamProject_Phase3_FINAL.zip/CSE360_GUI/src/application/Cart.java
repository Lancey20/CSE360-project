package application;
import java.util.ArrayList;

public class Cart {
	//cart class used to create an instance of cart object for user to add items to
	
	private ArrayList<MenuItem> itemsInCart = new ArrayList<MenuItem>(100);

	public ArrayList<MenuItem> cartList()	
	{
		
		
		return itemsInCart;
	}
	
	public boolean addItem(MenuItem item)
	{
		itemsInCart.add(item);
		
		return true;
	}
	
	public boolean removeItem(MenuItem item)
	{
		if(!(itemsInCart.isEmpty()))
		{
			for(int i = 0; i < itemsInCart.size(); i++)
			{
				if(itemsInCart.get(i).getName().equals(item.getName()))
				{
					itemsInCart.remove(i);
					return true;
				}
			}
		}
		
		return false;
	}
	
	public int findItem(MenuItem item)
	{
		int numItem = 0;
		
		for(int k = 0; k < itemsInCart.size(); k++)
		{
			if(itemsInCart.get(k).getName().equals(item.getName()))
			{
				numItem++;
			}
		}
		
		return numItem;
	}
	
	public double showTotal()
	{
		MenuItem temp;
		double total = 0;
		
		for(int j = 0; j < itemsInCart.size(); j++) //need menuItem class
		{
			temp = itemsInCart.get(j);
			total = total + temp.getPrice();
		}
		return total;
	}
	

	
	public int numbercartItems()
	{
		int totalitems = itemsInCart.size();
		
		return totalitems;
	}
	
	public MenuItem getAtIndex(int index)
	{
		return itemsInCart.get(index);
	}

}