package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;


public class CartBorderPane extends BorderPane{
	//initialize variables to be used by functions
	private Button menu;
	private Button account;
	private Button checkout;
	private FontWeight weight = FontWeight.BOLD;
	private FontPosture posture = FontPosture.REGULAR;
	private Cart currentCart;
	private String couponText;
	private Button applyCoupon;
	private Coupon couponCode;
	private double discountamt;
	private double totalAmt;
	private TextField enterCoupon;
	private Label discount;
	private Label total;
	
	//used to update main on current cart items
	public void updatedCart(Cart cart)
	{
		currentCart = cart;
	}
	
	public CartBorderPane(Cart cart, Menu menuList, Coupon coupon) {
		//currentCart holds the cart contents from the main
		currentCart = cart;
		//menuTemp holds menuList from the main
		Menu menuTemp = menuList;
		
		//couponCode holds current coupon object from main
		couponCode = coupon;
		//currentCart is currently hard coded in
		currentCart.addItem(menuTemp.getAtIndex(0));
		currentCart.addItem(menuTemp.getAtIndex(3));
		
		//create all the panes for use
		VBox overAllCart = new VBox();
		Pane header = new Pane();
		VBox itemList = new VBox();
		BorderPane info = new BorderPane();
		VBox infoOrder = new VBox();
		HBox infoO = new HBox();
		
		itemList.setPadding(new Insets(12, 12, 12, 12));
		info.setPadding(new Insets(12, 12, 12, 12));
		
		//create stuff to go into header pane
		Label title = new Label("Restaurant Name");
		title.setFont(Font.font("Hecvetica",weight, posture, 15));
		title.relocate(235, 10);
		account = new Button("Account");
		account.relocate(10, 10);
		menu = new Button("Back to Menu");
		menu.relocate(485, 10);
		checkout = new Button("Checkout");
		checkout.relocate(485,500);
		checkout.setPadding(new Insets(6, 6, 6, 6));

		//label for top of page
		Label viewMyOrder = new Label("View My Cart");
		viewMyOrder.relocate(220, 50);
		viewMyOrder.setFont(Font.font("Hecvetica",weight, posture, 24));
		Pane titleView = new Pane();
		titleView.getChildren().add(viewMyOrder);
		
		//go through each cart item and add a pane for it to the overall scene
		int len = currentCart.numbercartItems();
		
		for(int i = 0; i < len; i++)
		{
			Label cb = new Label("\n\t" + currentCart.getAtIndex(i).getName() + "\n\t\t$" + currentCart.getAtIndex(i).getPrice() + "0");
			cb.resize(500, 75);
			
			Image image = new Image(getClass().getResourceAsStream(currentCart.getAtIndex(i).getLink()));
			ImageView addImage = new ImageView(image);
			addImage.setFitHeight(60);
			addImage.setFitWidth(60);
			
			int numOfItem = currentCart.findItem(currentCart.getAtIndex(i));
			
			VBox countbuttons = new VBox();
			Label count = new Label("Count: " + numOfItem);
			Button remove = new Button("Remove");
			
			countbuttons.getChildren().addAll(count, remove);
			countbuttons.relocate(490,20);
			countbuttons.setPadding(new Insets(6, 6, 6, 300));
			
			BorderPane addedItem = new BorderPane();
			
			addedItem.setStyle("-fx-border-color: black");
			addedItem.relocate(20, 100);
			addedItem.setLeft(addImage);
			addedItem.setCenter(cb);
			addedItem.setRight(countbuttons);
			addedItem.setMinHeight(75);
			addedItem.setMinWidth(540);
			addedItem.setPadding(new Insets(12,12,12,12));
			itemList.getChildren().add(addedItem);
			itemList.setPadding(new Insets(12,12,12,12));
		}

		
		//items in cart currently hard coded in
		
		//information at bottom of checkout setup here
		applyCoupon = new Button("ApplyCoupon");
		Label couponcode = new Label("EnterCoupon:");
		couponcode.relocate(320, 400);
		couponcode.setPadding(new Insets(6, 6, 6, 6));
		enterCoupon = new TextField();
		enterCoupon.setPadding(new Insets(6, 6, 6, 6));
		enterCoupon.relocate(400, 400);
		discountamt = 0.00;
		
		
		//create label for Total
		totalAmt = 0;
		int num = 0;
		for(int t = 0; t < currentCart.numbercartItems(); t++)
		{
			totalAmt = totalAmt + currentCart.getAtIndex(t).getPrice();
			num++;
		}
		
		
		//set total amount
		total = new Label("Total: \t\t\t\t$" + totalAmt);
		total.relocate(320, 475);
		total.setPadding(new Insets(6, 6, 6, 6));
		
		//set number of items in order
		Label itemsinorder = new Label("Items in order: \t\t" + num);
		itemsinorder.relocate(320, 425);
		itemsinorder.setPadding(new Insets(6, 6, 6, 6));
		//set discound amount
		discount = new Label("Discount: \t\t\t\t$" + discountamt);
		discount.relocate(320, 450);
		discount.setPadding(new Insets(6, 6, 6, 6));
		
		//Add everything to panes then add to overAllCart
		header.getChildren().addAll(account, title, menu);
		infoOrder.getChildren().addAll(couponcode,itemsinorder,discount,total,checkout);
		VBox couponstuff = new VBox();
		couponstuff.getChildren().addAll(enterCoupon, applyCoupon);
		infoO.getChildren().addAll(infoOrder,couponstuff);
		info.setRight(infoO);
		overAllCart.getChildren().addAll(header,titleView,itemList,info);
		
		ButtonHandlerCoupon handle = new ButtonHandlerCoupon();
		applyCoupon.setOnAction(handle);
		
		//add everything to the borderpane
		this.setCenter(overAllCart);
		
		
	}
	
	//these functions take the stage to a different scene when called
	public void buttonCheckout(Stage window, Scene test)
	{
		checkout.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonMenu(Stage window, Scene test)
	{
		menu.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonAccount(Stage window, Scene test)
	{
		account.setOnAction(e -> window.setScene(test));
	}
	
    public Cart returnList()
    {
    	return currentCart;
    }
    
    //button handler for coupon
	private class ButtonHandlerCoupon implements EventHandler<ActionEvent>
	{
		public void handle(ActionEvent event)
		{
			//get coupon code entered
			couponText = enterCoupon.getText();
			
			//if it is a correct coupon code then clear the testfield and update discound amount and total amount
			if(couponText.equals(couponCode.getCode()))
			{
				enterCoupon.clear();
				discountamt = couponCode.getDiscount();
				totalAmt = totalAmt - discountamt;
				
				total.setText(("Total: \t\t\t\t$" + totalAmt));
				discount.setText("Discount: \t\t\t\t$" + discountamt);
			}
    	}
    }
	
}

