package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;

public class LoginBorderPane extends BorderPane{
	//initialize variables to be used in the functions
	private FontWeight weight = FontWeight.BOLD;
	private FontPosture posture = FontPosture.REGULAR;
	private TextField username;
	private TextField passwrd;
	private Label error;
	private Label success = new Label("");
	private Button login;
	private Stage window2;
	private boolean signIn;
	private Button crAcc;
	private Button backToMenu;
	private UserList listTemp;
	private Button restAccount;
	private VBox loginScreen;
	private Button custAccount;
	private ViewCustAcc tempAcc;
	
	//LoginBorderPane asks for a customer account object so that it can call its function setValues so it can get necessary values for ViewCustAcc
	public LoginBorderPane(ViewCustAcc acc) {
		
		//set up temp value and create vbox to hold all of the panes
		tempAcc = acc;
		loginScreen = new VBox();
		BorderPane buttons = new BorderPane();
		loginScreen.setPadding(new Insets(12,12,12,12));
		
		
		//set up label to display restaurant name and set up pane to hold title
		Label rest = new Label("Restaurant Name");
		rest.setFont(Font.font("Hecvetica",weight, posture, 15));
		rest.relocate(225, 10);
		Pane titleof = new Pane();
		titleof.getChildren().add(rest);
		titleof.setPadding(new Insets(12,12,12,12));
		
		//create a button for create account
		crAcc = new Button("Create Account");
		crAcc.setPadding(new Insets(12,12,12,12));
		
		//create a menu button
		backToMenu = new Button("Menu");
		backToMenu.setPadding(new Insets(12,12,12,12));

		//create a login button
		login = new Button("Login");
		login.setPadding(new Insets(12,12,12,12));

		//create a username textField
		username = new TextField();
		username.setPadding(new Insets(12,12,12,12));

		//create a password textField
		passwrd = new TextField();
		passwrd.setPadding(new Insets(12,12,12,12));

		//create a username to indicate what textfield is for username
		Label usrnameL = new Label("Username");
		usrnameL.setPadding(new Insets(12,12,12,12));

		//create a username to indicate what textfield is for password
		Label psswrd = new Label("Password");
		psswrd.setPadding(new Insets(12,12,12,12));

		Label signedIn = new Label("You are already signed in!");
		
		//create buttons for when each type of user is signed in
		restAccount = new Button("Restaurant Account");
		custAccount = new Button("Customer Account");
		
		//set buttons in pane
		buttons.setLeft(crAcc);
		buttons.setRight(login);
		buttons.setPadding(new Insets(12,12,12,12));
		//add everything to the overall pane
		loginScreen.getChildren().addAll(backToMenu,titleof,success,usrnameL,username,psswrd,passwrd,buttons);
		
		//create handler and set login button to handlelogin on action
		LoginHandler handlelogin = new LoginHandler();
		login.setOnAction(handlelogin);
		
		//set loginScreen to the borderpane
		this.setCenter(loginScreen);
	}
	
	//gets the list of users from the main class
	public void getListOfUsers(UserList list)
	{
		listTemp = list;
	}
	
	private class LoginHandler implements EventHandler<ActionEvent>
	{
		public void handle(ActionEvent event)
		{
			//create temp user to search userlist for user login attempt
			String user = username.getText();
			String pass = passwrd.getText();
			User temp = new User();
			temp.setName(user);
			temp.setPassword(pass);
			signIn = false;
			
			int index = listTemp.searchFor(temp);
			
				//if index is within bounds
				if(listTemp.searchFor(temp) != 100000000)
				{
					if(listTemp.isRestaurant(temp) == false)	//and it is not the restaurant account
					{
						
						//clear testfields and add success message, also add customer account button so they can look at their information
						username.clear();
						passwrd.clear();
						loginScreen.getChildren().add(custAccount);
						success.setText("Sign in Successful!");
						//set signed in to true and set the users status to signed in
						signIn = true;
						success.setTextFill(Color.GREEN);
						listTemp.getUser(index).setLoginStatus(true);
						tempAcc.setValues();
							
					}else if(listTemp.isRestaurant(temp) == true){
						//if it is the restaurant user add success message and restaurant account button as well as clear textfields
						loginScreen.getChildren().add(restAccount);
						success.setText("Sign in Successful! Click Restaruant Account to go to Account Info");
						success.setTextFill(Color.GREEN);
						listTemp.getUser(index).setLoginStatus(true);
						username.clear();
						passwrd.clear();
						signIn = true;
					}
				}
			
						
			//if user was not found set up unsuccessful message
			if(signIn == false)
			{
				success.setText("Sign in Unsuccessful, please try again!");
				success.setTextFill(Color.RED);
				username.clear();
				passwrd.clear();
			}
		}
	}
	
	//all of these functions are to get to different scenes
	//this one is to get to the menu when backToMenu button is pushed
	public void buttonBackToMenu(Stage window, Scene test)
	{
		backToMenu.setOnAction(e -> window.setScene(test));
	}
	
	//this one is to get to create account when crAcc button is pushed
	public void buttonCreateAccount(Stage window, Scene test)
	{
		crAcc.setOnAction(e -> window.setScene(test));
	}
	
	//this one is to get to restaurant account page when restAccount is pushed
	public void buttonRestaurantAccount(Stage window, Scene test)
	{
		restAccount.setOnAction(e -> window.setScene(test));
	}
	
	//this one is to get to customer account page when custAccount is pushed
	public void buttonCustomerAccount(Stage window, Scene test)
	{
		custAccount.setOnAction(e -> window.setScene(test));
	}

}
