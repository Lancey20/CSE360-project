package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.layout.StackPane;


public class Main extends Application {


	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			//window is the overall stage that will be used
			Stage window = primaryStage;
			
			//initializing the userlist and a restaurant admin account
			UserList listOfUsers = new UserList();
			User restaurant = new User();
			restaurant.setName("Manager");
			restaurant.setPassword("1234");
			restaurant.setLoginStatus(false);
			listOfUsers.addUser(restaurant);
			
			//initializing the menulist to be added to
			Menu menuList = new Menu();
			
			//initializing the coupon to welcomeback. this can be changed by the restaurant admin
			Coupon newCoupon = new Coupon();
			newCoupon.setCode("welcomeback");
			newCoupon.setDiscount(2);
			newCoupon.setAvailable(true);
			
			//starting a cartlist to be added to
			Cart cartList = new Cart();

			//create all of the pages as objects so the main can switch between pages******************************************************
			CreateAccountBorderPane createAccount = new CreateAccountBorderPane(listOfUsers);
			CartBorderPane cart = new CartBorderPane(cartList,menuList,newCoupon);
			OrderStatusBorderPane orderConf = new OrderStatusBorderPane();
			AddNewItem newItem = new AddNewItem();
			RestaurantProfile restProfile = new RestaurantProfile();
			UpdateItem update = new UpdateItem();
			RemoveItem remove = new RemoveItem();
			CouponPane coupon = new CouponPane(newCoupon);
			MenuBorderPane menu = new MenuBorderPane(cartList);
			PaymentPage payment = new PaymentPage();
			ViewCustAcc viewCust = new ViewCustAcc(listOfUsers,newCoupon);
			LoginBorderPane login = new LoginBorderPane(viewCust);
			//*******************************************************************************************************************************
			
			//adding those pages to stackpanes then to a scene to be ready for the main to use************************************************
			StackPane cartPane = new StackPane();
			cartPane.getChildren().add(cart);
			Scene cartScene = new Scene(cartPane, 500, 500);
			
			StackPane orderConfPane = new StackPane();
			orderConfPane.getChildren().add(orderConf);
			Scene orderConfScene = new Scene(orderConfPane, 500, 500);
			
			StackPane createAccountPane = new StackPane();
			createAccountPane.getChildren().add(createAccount);
			Scene createAccountScene = new Scene(createAccountPane, 800, 500);
			
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 500, 500);
			
			StackPane newItemPane = new StackPane();
			newItemPane.getChildren().add(newItem);
			Scene newItemScene = new Scene(newItemPane, 800, 500);
			
			StackPane restProfilePane = new StackPane();
			restProfilePane.getChildren().add(restProfile);
			Scene restProfileScene = new Scene(restProfilePane, 800, 500);
			
			StackPane updateItemPane = new StackPane();
			updateItemPane.getChildren().add(update);
			Scene updateItemScene = new Scene(updateItemPane, 800, 500);
			
			StackPane removeItemPane = new StackPane();
			removeItemPane.getChildren().add(remove);
			Scene removeItemScene = new Scene(removeItemPane, 800, 500);
			
			StackPane couponpanePane = new StackPane();
			couponpanePane.getChildren().add(coupon);
			Scene CouponpaneScene = new Scene(couponpanePane, 800, 500);
			
			StackPane paymentPane = new StackPane();
			paymentPane.getChildren().add(payment);
			Scene paymentScene = new Scene(paymentPane, 800, 500);
			
			StackPane viewCustPane = new StackPane();
			viewCustPane.getChildren().add(viewCust);
			Scene viewCustScene = new Scene(viewCustPane, 800, 500);
			
			//adding menu to stackpane then mainscene as it will be the scene the GUI opens to
			StackPane menuPane = new StackPane();
			menuPane.getChildren().add(menu);
			Scene mainscene = new Scene(menuPane, 500, 500);
			//**************************************************************************************************************************
			
			
			//Calling all of the functions needed from the other classes*********************************************************************
			//All of the button functions for the login page
			login.buttonCreateAccount(window, createAccountScene);
			login.buttonBackToMenu(window, mainscene);
			login.getListOfUsers(listOfUsers);
			login.buttonRestaurantAccount(window, restProfileScene);
			login.buttonCustomerAccount(window, viewCustScene);
			
			//All of the button functions for the restaurant account page
			restProfile.backToMenuButton(window, mainscene);
			restProfile.AddNewItemButton(window, newItemScene);
			restProfile.UpdateItemButton(window, updateItemScene);
			restProfile.RemoveItemButton(window, removeItemScene);
			restProfile.CreateCouponButton(window, CouponpaneScene);

			//All of the button functions for the menu page
			menu.getList(menuList);
			cartList = menu.returnCart();
			cart.updatedCart(cartList);
			menu.buttonCart(window, cartScene);
			menu.buttonLogin(window, loginScene);
			
			//calling all button functions type classes for cart
			cart.buttonCheckout(window, paymentScene);
			cart.buttonMenu(window, mainscene); 
			cart.buttonAccount(window, loginScene);
			
			//All of the button functions for the create account page
			listOfUsers = createAccount.returnList();
			createAccount.buttonMenu(window, mainscene);
			
			//All of the button functions for the Order Confirmation page
			orderConf.backToAccountButton(window, viewCustScene);
			orderConf.backToMenuButton(window, mainscene);
			orderConf.backToHomeButton(window, mainscene);
			
			//All of the button functions for the add new Item Page
			newItem.backToProfileButton(window, restProfileScene);
			
			//All of the button functions for the update Item Page
			update.backToProfileButton(window, restProfileScene);
			
			//All of the button functions for the remove Item Page
			remove.backToProfileButton(window, restProfileScene);
			
			//All of the button functions for the remove Item Page
			coupon.backToProfileButton(window, restProfileScene);
			
			//All of the button functions for the Payment Page
			payment.backToLogin(window, loginScene);
			payment.backToMenuButton(window, mainscene);
			payment.orderConformationPage(window, orderConfScene);
			
			//viewCustomerAccount functions
			viewCust.menuBut(window, mainscene);
			//*******************************************************************************************************************************
			
			//set up the window to be shown
			window.setScene(mainscene);
			window.setHeight(700);
			window.setWidth(650);
			window.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}

