package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MenuBorderPane extends BorderPane{
	private Button goToCart;
	private Button login;
	private TextField search;
	private FontWeight weight = FontWeight.BOLD;
	private FontPosture posture = FontPosture.REGULAR;
	private Menu listTemp;
	private Menu newList;
	private Button test;
	private VBox header;
	private Label added;
	private Cart cartTemp;
	private Button[] addToCartButtons = new Button[100];
	private ButtonHandler[] handlers = new ButtonHandler[100];
	
	public void getList(Menu list) throws FileNotFoundException
    {
    	listTemp = list;
    	
    	
    	int len = listTemp.numOfItems();
    	
		for(int i = 0; i < len; i++)
		{
			Label cb = new Label("\n\t" + listTemp.getAtIndex(i).getName() + "\n\t\t$" + listTemp.getAtIndex(i).getPrice() + "0");
			cb.resize(500, 75);
			added = new Label("");
			HBox labels = new HBox();
			labels.getChildren().addAll(cb,added);
			labels.setPadding(new Insets(6,6,6,6));
			
			//InputStream stream = new FileInputStream(listTemp.getAtIndex(i).getLink());
			Image image = new Image(getClass().getResourceAsStream(listTemp.getAtIndex(i).getLink()));
			ImageView addImage = new ImageView(image);
			addImage.setFitHeight(60);
			addImage.setFitWidth(60);
			
			
			VBox countbuttons = new VBox();
			
			addToCartButtons[i] = new Button("Add to Cart");;
			
			countbuttons.getChildren().addAll(addToCartButtons[i]);
			countbuttons.relocate(490,20);
			countbuttons.setPadding(new Insets(6, 6, 6, 300));
			
			BorderPane addedItem = new BorderPane();
			
			//cb.setStyle("-fx-border-color: black");
			addedItem.setStyle("-fx-border-color: black");
			addedItem.relocate(20, 100);
			addedItem.setLeft(addImage);
			addedItem.setCenter(cb);
			addedItem.setRight(countbuttons);
			addedItem.setMinHeight(75);
			addedItem.setMinWidth(540);
			addedItem.setPadding(new Insets(12,12,12,12));
			header.getChildren().add(addedItem);
			header.setPadding(new Insets(12,12,12,12));
			
			handlers[i] = new ButtonHandler();
			addToCartButtons[i].setOnAction(handlers[i]);
			
		}
		
		
    }
	
	public MenuBorderPane(Cart cart)
	{
		//holds the users items while they add stuff
		cartTemp = cart;
		
		//create Scroll so user can scroll through options
		ScrollPane scrollMenu = new ScrollPane();
		scrollMenu.setPrefSize(800, 500);
		
		
		//create top pane
		header = new VBox();
		Pane headerInsides = new Pane();
		Label title = new Label("Restaurant Name");
		title.setFont(Font.font("Hecvetica",weight, posture, 15));
		title.relocate(235, 10);
		goToCart = new Button("Cart");
		goToCart.relocate(485, 10);
		goToCart.setPadding(new Insets(12,12,12,12));
		login = new Button("Login");
		login.relocate(10, 10);
		login.setPadding(new Insets(12,12,12,12));
		headerInsides.getChildren().addAll(login,title,goToCart);
		headerInsides.setPadding(new Insets(12,12,12,12));
		header.getChildren().addAll(headerInsides);
		scrollMenu.setContent(header);
		
		//add everything to borderpane
		this.setCenter(scrollMenu);
		
	}
	
	//these are functions for the stage to go to another scene when called by main
	public void buttonCart(Stage window, Scene test)
	{
		goToCart.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonLogin(Stage window, Scene test)
	{
		login.setOnAction(e -> window.setScene(test));
	}
	
	//button handler for add item to cart
	private class ButtonHandler implements EventHandler<ActionEvent>
	{
		public void handle(ActionEvent event)
		{
			
			//set label to say item was added
			added = new Label("Item Added to Cart!");
			
			int len = listTemp.numOfItems();
	    	
			//add the item from the menulist
			for(int i = 0; i < len; i++)
			{
				
				 if(event.getSource().equals(addToCartButtons[i]))
				 {
					 cartTemp.addItem(listTemp.getAtIndex(i));
				 }
				
			}
			
		}
	}
	
	//return cart value to the main when called
	public Cart returnCart()
	{
		return cartTemp;
	}
	
}

