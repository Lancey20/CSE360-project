package application;

public class MenuItem{
private String name;
private double price;
private String ingredients;
private String type;
private String link;

//menuitem class creates an item that can be added to the menu list which is in Menu.java
	public void createMenuItem(String newName, double newPrice, String newIngredients, String newType, String newlink){ 
		name = newName;
		price = newPrice;
		ingredients = newIngredients;
		type = newType;
		link = newlink;
	} 
	
	public void setName(String updateName){
	    name = updateName;
	}
	
	public void setPrice(double updatePrice)
	{
		price = updatePrice;
	}
	
	public void setIngredients(String updateIngredients)
	{
		ingredients = updateIngredients;
	}
	
	public void setType(String updateType)
	{
		type = updateType;
	}
	
	public void setImage(String newLink)
	{
		link = newLink;
	}
	
	public String getName()
	{
		return name;
	}
	
	public double getPrice()
	{
		return price;
	}
	
	public String getIngredients()
	{
		return ingredients;
	}
	
	public String getType()
	{
		return type;
	}
	
	public String getLink()
	{
		return link;
	}
}