package application;

public class OrderStatus {
	//uncomment all arraylist once menu item is in place
	
	//private ArrayList<menuList> itemsList = new ArrayList<>();
	private int waitTime;
	private int placeInLine;
	
	
	public OrderStatus() {
		//itemsList = {"Pizza"}
		waitTime = 0;
		placeInLine = 0;
	}
	
	/*
	 public menuList getItemsList(){
	 	return itemsList();
	 }
	 */
	
	public int getWaitTime() {
		return waitTime;
	}
	
	public int getPlaceInLine() {
		return placeInLine;
	}
	
	/*
	 public void setItemsList(menuItem itemsList){
	 	this.itemsList = itemsList;
	 }
	 */
	
	public void setWaitTime(int waitTime) {
		this.waitTime = waitTime;
	}
	
	public void setPlaceInLine(int placeInLine) {
		this.placeInLine = placeInLine;
	}
	
	
	public int waitTime() {
		return waitTime;
	}
	public int placeInLine() {
		return placeInLine;
	}
}