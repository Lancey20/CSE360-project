package application;

import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class OrderStatusBorderPane extends BorderPane{
	//these are the buttons and labels
	private Button account;
	private Button back;
	private Button cancel;
	private Label restaurant;
	private Label orders;
	private Label wait;
	private Label soon;
	private Label thanks;
	
	public OrderStatusBorderPane() {
		//this will create the buttons used at the top to navigate
		account = new Button("Account");
		account.setMinSize(50, 50);
		restaurant = new Label("Restaurant Name");
		restaurant.setMinSize(50, 50);
		back = new Button("Back");
		back.setMinSize(50, 50);
		HBox topButtons = new HBox();
		topButtons.setPadding(new Insets(20, 20, 20, 20));
		topButtons.setSpacing(50);
		topButtons.setAlignment(Pos.CENTER);
		topButtons.getChildren().addAll(account, restaurant,
				back);
		this.setTop(topButtons);
		
		VBox confirmation = new VBox();
		//This is the hardcode section
		soon = new Label("Thank you for your order, it will be ready soon");
		soon.setFont(Font.font("BOLD", 20));
		orders = new Label("There are 0 orders in front of you.");
		orders.setFont(Font.font("BOLD", 18));
		wait = new Label("Approximate orders time: 15 minutes");
		wait.setFont(Font.font("BOLD", 18));
		cancel = new Button("Cancel");
		cancel.setMinSize(50,  50);
		cancel.setPadding(new Insets(20, 20, 20, 20));
		confirmation.setSpacing(40);
		confirmation.setAlignment(Pos.CENTER);
		//end of hardcode section
		confirmation.getChildren().addAll(soon, orders, wait, cancel);
		
		this.setCenter(confirmation);
	}
	
	public void backToAccountButton(Stage window, Scene test)
	{
		account.setOnAction(e -> window.setScene(test));
	}
	
	public void backToMenuButton(Stage window, Scene test)
	{
		back.setOnAction(e -> window.setScene(test));
	}
	
	public void backToHomeButton(Stage window, Scene test)
	{
		cancel.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
        		Alert positive = new Alert(Alert.AlertType.INFORMATION, "Are you sure? Continuing will cancel your order!");
        		positive.showAndWait();
    			cancel.setOnAction(e -> window.setScene(test));
			};
		});
	}
}
