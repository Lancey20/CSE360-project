package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Scene;


public class PaymentPage extends BorderPane{
	//these are the buttons and textfields so they can be called by the event handlers
	private Button login;
	private Button edit;
	private Button payNow;
	private Button save;
	private TextField name;
	private TextField address;
	private TextField card;
	private TextField ccv;
	private TextField expiration;
	private TextField phone;
	
	public PaymentPage() {
		//vbox is needed to set login and instructions on top of the page
		VBox header = new VBox();
		login = new Button("Or Login To Existing Account");
		login.setWrapText(true);
		login.setPrefSize(200, 40);
		Label instructions = new Label("Please Enter Your Payment Information");
		instructions.setFont(Font.font("BOLD",24));
		instructions.setWrapText(true);
		header.setSpacing(10);
		header.setAlignment(Pos.CENTER);
		header.getChildren().addAll(instructions, login);
		this.setTop(header);
		
		//these are the textfields that the user will enter their information in
		VBox cardInfo = new VBox();
		name = new TextField();
		name.setMaxWidth(400);
		address = new TextField();
		address.setMaxWidth(400);
		card = new TextField();
		card.setMaxWidth(400);
		ccv = new TextField();
		ccv.setMaxWidth(400);
		expiration = new TextField();
		expiration.setMaxWidth(400);
		phone = new TextField();
		phone.setMaxWidth(400);
		cardInfo.setSpacing(30);
		cardInfo.setAlignment(Pos.CENTER);
		cardInfo.getChildren().addAll(name, address, card, ccv, expiration, phone);
		this.setCenter(cardInfo);
		
		//these are the labels that will let the user know what goes in what textfield
		VBox description = new VBox();
		Label fullName = new Label("Name On Card");
		Label billingAddress = new Label("Billing Address");
		Label cardNumber = new Label("Card Number");
		Label ccvNumber = new Label("CCV Number");
		Label expirationDate = new Label("Expiration Date");
		Label phoneNumber = new Label("Phone Number");
		description.setSpacing(38);
		description.setAlignment(Pos.CENTER_LEFT);
		description.getChildren().addAll(fullName, billingAddress, cardNumber, ccvNumber, expirationDate,
				phoneNumber);
		this.setLeft(description);
		
		//these buttons will take you to different pages 
		HBox footer = new HBox();
		edit = new Button("Edit Order");
		edit.setMinSize(50,50);
		payNow = new Button("Pay Now");
		payNow.setMinSize(50, 50);
		save = new Button("Save Payment Information");
		save.setMinSize(50,50);
		footer.getChildren().addAll(edit, payNow, save);
		footer.setSpacing(50);
		footer.setAlignment(Pos.TOP_CENTER);
		this.setBottom(footer);
		
		//this makes it so everything is 20 pixels off of the borders
		this.setPadding(new Insets(20, 20, 20, 20));
		
		//this will let the user know that their information has been saved
		//TODO: this is currently hard coded and needs to be unhard coded for the next phase
		save.setOnAction(new EventHandler<ActionEvent>() {
			@Override public void handle(ActionEvent e) {
				save.setText("Information Saved!");
			}
		});
	}
	
	//this will send the user back to the login screen if they click the login button 
	public void backToLogin(Stage window, Scene test)
	{
		login.setOnAction(e -> window.setScene(test));
	}
	
	//this will send the user back to the menu if they select it
	public void backToMenuButton(Stage window, Scene test)
	{
		edit.setOnAction(e -> window.setScene(test));
	}
	
	//this will determine if the user can pay
	public void orderConformationPage(Stage window, Scene test)
	{
        payNow.setOnAction(new EventHandler<ActionEvent>() {
        	//this is to check if all 6 textfields have been filled out
    		int count = 0;
            @Override
            public void handle(ActionEvent event) {
            	//these if statements will check to see if any textfield is empty
            	if(name.getText().isEmpty() || address.getText().isEmpty() || card.getText().isEmpty() ||
            			ccv.getText().isEmpty() || expiration.getText().isEmpty() || phone.getText().isEmpty()) {
            		//if it is, then an alert will pop up
            		Alert notComplete = new Alert(Alert.AlertType.ERROR, "Please fill in all text fields!");
            		notComplete.showAndWait();
            	} else {
            		//this will let the user go to the payment page if all information has been filled out
            		payNow.setOnAction(e -> window.setScene(test));
            	}
            }
        });
	}
	
}
