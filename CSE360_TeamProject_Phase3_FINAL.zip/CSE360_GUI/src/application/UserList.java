package application;

import java.util.ArrayList;

public class UserList {
	//the userlist class creates a list of users that the main can call to store all of its user objects

	private ArrayList<User> userList = new ArrayList<User>(100);
	
	
	//add a user
	public void addUser(User user)
	{
		userList.add(user);
	}
	
	
	//remove a user
	public void removeUser(User user)
	{
		int remove = searchFor(user);
		
		if(remove == 100000000)
		{
			userList.remove(remove);
		}
	}
	
	
	//reutrn list size
	public int numOfUsers()
	{
		return userList.size();
	}
	
	
	//search for user entered return index if found and 100000000 if it is not
	public int searchFor(User user)
	{
		for(int i = 0; i < userList.size(); i++)
		{
			if(user.getName().equals(userList.get(i).getName()))
			{
				if(user.getPassword().equals(userList.get(i).getPassword()))
				{
					return i;
				}
			}
		}
		return 100000000;
	}
	
	
	//return user at int index
	public User getUser(int index)
	{
		return userList.get(index);
	}
	

	//if it is a restaurant profile return true
	public boolean isRestaurant(User user)
	{
		for(int i = 0; i < userList.size(); i++)
		{
			if(user.getName().equals("Manager"))
			{
				if(user.getPassword().equals("1234"))
				{
					return true;
				}
			}
		}
		return false;
		
	}
	
}

