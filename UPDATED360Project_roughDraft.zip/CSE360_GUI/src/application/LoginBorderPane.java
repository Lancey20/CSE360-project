package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;

public class LoginBorderPane extends BorderPane{
	FontWeight weight = FontWeight.BOLD;
	FontPosture posture = FontPosture.REGULAR;
	TextField username;
	TextField passwrd;
	Label error;
	Label success = new Label("");
	Button login;
	Stage window2;
	boolean signIn;
	Button crAcc;
	Button backToMenu;
	UserList listTemp;
	Button restAccount;
	VBox loginScreen;
	
	
	public LoginBorderPane() {
		
		loginScreen = new VBox();
		BorderPane buttons = new BorderPane();
		loginScreen.setPadding(new Insets(12,12,12,12));
		
		Label rest = new Label("Restaurant Name");
		rest.setFont(Font.font("Hecvetica",weight, posture, 15));
		rest.relocate(225, 10);
		Pane titleof = new Pane();
		titleof.getChildren().add(rest);
		titleof.setPadding(new Insets(12,12,12,12));
		
		crAcc = new Button("Create Account");
		crAcc.setPadding(new Insets(12,12,12,12));
		
		backToMenu = new Button("Menu");
		backToMenu.setPadding(new Insets(12,12,12,12));

		//crAcc.relocate(50, 0);

		login = new Button("Login");
		login.setPadding(new Insets(12,12,12,12));

		username = new TextField();
		username.setPadding(new Insets(12,12,12,12));

		//username.relocate(200, 0);

		passwrd = new TextField();
		passwrd.setPadding(new Insets(12,12,12,12));

		//passwrd.relocate(200, 50);

		Label usrnameL = new Label("Username");
		usrnameL.setPadding(new Insets(12,12,12,12));

		Label psswrd = new Label("Password");
		psswrd.setPadding(new Insets(12,12,12,12));

		Label signedIn = new Label("You are already signed in!");
		
		restAccount = new Button("Restaurant Account");
		
		//If(signed in)
		//{
			
		//}
		
		
		buttons.setLeft(crAcc);
		buttons.setRight(login);
		buttons.setPadding(new Insets(12,12,12,12));
		loginScreen.getChildren().addAll(backToMenu,titleof,success,usrnameL,username,psswrd,passwrd,buttons);
		
		LoginHandler handlelogin = new LoginHandler();
		login.setOnAction(handlelogin);
		
		this.setCenter(loginScreen);
	}
	
	public void getListOfUsers(UserList list)
	{
		listTemp = list;
	}
	
	private class LoginHandler implements EventHandler<ActionEvent>
	{
		public void handle(ActionEvent event)
		{
			String user = username.getText();
			String pass = passwrd.getText();
			User temp = new User();
			temp.setName(user);
			temp.setPassword(pass);
			signIn = false;
			
			for(int i = 0; i < listTemp.numOfUsers(); i++)
			{
				if(listTemp.searchFor(temp) != 100000000)
				{
					if(listTemp.isRestaurant(temp) == false)
					{
						username.clear();
						passwrd.clear();
						success.setText("Sign in Successful!");
						signIn = true;
						success.setTextFill(Color.GREEN);
						//change to user info page	
					}else {
						
						loginScreen.getChildren().add(restAccount);
						success.setText("Sign in Successful! Click Restaruant Account to go to Account Info");
						success.setTextFill(Color.GREEN);
						username.clear();
						passwrd.clear();
						signIn = true;
					}
				}
			}
						
			if(signIn == false)
			{
				success.setText("Sign in Unsuccessful, please try again!");
				success.setTextFill(Color.RED);
				username.clear();
				passwrd.clear();
			}
		}
	}
	
	public void buttonBackToMenu(Stage window, Scene test)
	{
		backToMenu.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonCreateAccount(Stage window, Scene test)
	{
		crAcc.setOnAction(e -> window.setScene(test));
	}
	
	public void buttonRestaurantAccount(Stage window, Scene test)
	{
		restAccount.setOnAction(e -> window.setScene(test));
	}

}
