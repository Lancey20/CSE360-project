package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.layout.StackPane;


public class Main extends Application {


	
	@Override
	public void start(Stage primaryStage) {
		try {
			Stage window = primaryStage;
			
			UserList listOfUsers = new UserList();
			User restaurant = new User();
			restaurant.setName("Manager");
			restaurant.setPassword("1234");
			listOfUsers.addUser(restaurant);
			
			Menu menuList = new Menu();
			
			
			//MenuBorderPane menu = new MenuBorderPane();
			LoginBorderPane login = new LoginBorderPane();
			CreateAccountBorderPane createAccount = new CreateAccountBorderPane();
			CartBorderPane cart = new CartBorderPane();
			OrderStatusBorderPane orderConf = new OrderStatusBorderPane();
			AddNewItem newItem = new AddNewItem();
			RestaurantProfile restProfile = new RestaurantProfile();
			UpdateItem update = new UpdateItem();
			RemoveItem remove = new RemoveItem();
			CouponPane coupon = new CouponPane();
			
			StackPane cartPane = new StackPane();
			cartPane.getChildren().add(cart);
			Scene cartScene = new Scene(cartPane, 500, 500);
			
			Button menuTest = new Button("Go to Cart - Sub for Menu Pane");
			menuTest.setOnAction(e -> window.setScene(cartScene));
			StackPane paneTest = new StackPane();
			paneTest.getChildren().add(menuTest);
			
			Scene mainscene = new Scene(paneTest, 500, 500);
			
			StackPane orderConfPane = new StackPane();
			orderConfPane.getChildren().add(orderConf);
			Scene orderConfScene = new Scene(orderConfPane, 500, 500);
			
			StackPane createAccountPane = new StackPane();
			createAccountPane.getChildren().add(createAccount);
			Scene createAccountScene = new Scene(createAccountPane, 800, 500);
			
			StackPane loginPane = new StackPane();
			loginPane.getChildren().add(login);
			Scene loginScene = new Scene(loginPane, 500, 500);
			
			
			
			StackPane newItemPane = new StackPane();
			newItemPane.getChildren().add(newItem);
			Scene newItemScene = new Scene(newItemPane, 800, 500);
			
			StackPane restProfilePane = new StackPane();
			restProfilePane.getChildren().add(restProfile);
			Scene restProfileScene = new Scene(restProfilePane, 800, 500);
			
			StackPane updateItemPane = new StackPane();
			updateItemPane.getChildren().add(update);
			Scene updateItemScene = new Scene(updateItemPane, 800, 500);
			
			StackPane removeItemPane = new StackPane();
			removeItemPane.getChildren().add(remove);
			Scene removeItemScene = new Scene(removeItemPane, 800, 500);
			
			StackPane CouponpanePane = new StackPane();
			CouponpanePane.getChildren().add(coupon);
			Scene CouponpaneScene = new Scene(CouponpanePane, 800, 500);
			
			//calling all button handler type classes for cart
			cart.buttonCheckout(window, orderConfScene);
			cart.buttonMenu(window, mainscene); //orderConfScene will be changed to menu scene
			cart.buttonAccount(window, loginScene); //orderConfScene will be changed to account scene
			//when account button is pushed we will have to figure out how to check if user is already logged in and that
			//decides whether they go to login or account details
			
			
			//All of the button handlers for the login page
			login.buttonCreateAccount(window, createAccountScene);
			login.buttonBackToMenu(window, mainscene);
			login.getListOfUsers(listOfUsers);
			login.buttonRestaurantAccount(window, restProfileScene);
			
			//All of the button handlers for the restaurant account page
			restProfile.backToMenuButton(window, mainscene);
			restProfile.AddNewItemButton(window, newItemScene);
			restProfile.UpdateItemButton(window, updateItemScene);
			restProfile.RemoveItemButton(window, removeItemScene);
			restProfile.CreateCouponButton(window, CouponpaneScene);
			
			
			//Scene sceneTest = new Scene(paneTest, 800, 500);
			
			//All of the button handlers for the menu page
			
			//All of the button handlers for the create account page
			
			//All of the button handlers for the Order Confirmation page
			
			//All of the button handlers for the add new Item Page
			newItem.backToProfileButton(window, restProfileScene);
			
			//All of the button handlers for the update Item Page
			update.backToProfileButton(window, restProfileScene);
			
			//All of the button handlers for the remove Item Page
			remove.backToProfileButton(window, restProfileScene);
			
			//All of the button handlers for the remove Item Page
			coupon.backToProfileButton(window, restProfileScene);
			
			
			//setting up overall window
			//StackPane rootPane = new StackPane();
			//rootPane.getChildren().add(cart); //will start with menu not cart but don't have menu yet
			
			window.setScene(mainscene);
			window.setHeight(600);
			window.setWidth(600);
			window.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
